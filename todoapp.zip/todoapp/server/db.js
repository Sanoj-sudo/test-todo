import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';

// Return DATE columns as plain 'YYYY-MM-DD' strings instead of JS Dates,
// so due dates never shift because of server/client timezone differences.
pg.types.setTypeParser(1082, (value) => value);

function sslConfig() {
  if (process.env.DB_SSL !== 'true') return false;

  const caPath = path.resolve(process.env.DB_SSL_CA || 'certs/global-bundle.pem');
  if (fs.existsSync(caPath)) {
    return { ca: fs.readFileSync(caPath, 'utf8'), rejectUnauthorized: true };
  }

  console.warn(
    `[db] DB_SSL=true but CA bundle not found at ${caPath}. ` +
      'Connecting with TLS but WITHOUT certificate verification. ' +
      'Run deploy/setup-ec2.sh or download https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem'
  );
  return { rejectUnauthorized: false };
}

export const pool = new pg.Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 5432),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'todoapp',
  ssl: sslConfig(),
  max: Number(process.env.DB_POOL_MAX || 10),
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
});

pool.on('error', (err) => {
  console.error('[db] idle client error', err);
});

export async function migrate() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS todos (
      id          SERIAL PRIMARY KEY,
      title       TEXT        NOT NULL CHECK (char_length(title) BETWEEN 1 AND 500),
      completed   BOOLEAN     NOT NULL DEFAULT FALSE,
      priority    SMALLINT    NOT NULL DEFAULT 2 CHECK (priority BETWEEN 1 AND 3),
      due_date    DATE,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS todos_completed_created_idx ON todos (completed, created_at DESC);
  `);
}
